#!/usr/bin/python

import http.server
http.server.test()