# -*- coding: utf-8 -*-
# class Convert_device_id(object): 
#     def __init__(self, str_box_id, tmp_pos_x, tmp_pos_y): 
#         self.str_box_id = str_box_id 
#         self.tmp_pos_x = tmp_pos_x 
#         self.tmp_pos_y = tmp_pos_y

# 親機のidと座標
def convert_box_id(str_box_id):

  if str_box_id == "XXXXXXXX":
    str_box_id = 1
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "XXXXXXXX":
    str_box_id = 2
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "XXXXXXXX":
    str_box_id = 3
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "XXXXXXXX":
    str_box_id = 4
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "XXXXXXXX":
    str_box_id = 5
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010006":
    str_box_id = 6
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010007":
    str_box_id = 7
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010008":
    str_box_id = 8
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010009":
    str_box_id = 9
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D01000A":
    str_box_id = 10
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D01000B":
    str_box_id = 11
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D01000C":
    str_box_id = 12
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D01001B":
    str_box_id = 13
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D01001C":
    str_box_id = 14
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D01001D":
    str_box_id = 15
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D01001E":
    str_box_id = 16
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D01001F":
    str_box_id = 17
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010020":
    str_box_id = 18
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010021":
    str_box_id = 19
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010022":
    str_box_id = 20
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010023":
    str_box_id = 21
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010024":
    str_box_id = 22
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010025":
    str_box_id = 23
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010026":
    str_box_id = 24
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010027":
    str_box_id = 25
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010028":
    str_box_id = 26
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010029":
    str_box_id = 27
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D01002A":
    str_box_id = 28
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D01002B":
    str_box_id = 29
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D01002C":
    str_box_id = 30
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D01002D":
    str_box_id = 31
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D01002E":
    str_box_id = 32
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D01002F":
    str_box_id = 33
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010030":
    str_box_id = 34
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010031":
    str_box_id = 35
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010032":
    str_box_id = 36
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010033":
    str_box_id = 37
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010034":
    str_box_id = 38
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010035":
    str_box_id = 39
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010036":
    str_box_id = 40
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010037":
    str_box_id = 41
    tmp_pos_x = 0
    tmp_pos_y = 0
  elif str_box_id == "9CBD9D010038":
    str_box_id = 42
    tmp_pos_x = 0
    tmp_pos_y = 0

  else:
    str_box_id = 999
    tmp_pos_x = 0
    tmp_pos_y = 0

  tmp_list = [str_box_id, tmp_pos_x, tmp_pos_y]

  return tmp_list #[str_box_id, tmp_pos_x, tmp_pos_y]

  # return Convert_device_id(str_box_id, tmp_pos_x, tmp_pos_y)
